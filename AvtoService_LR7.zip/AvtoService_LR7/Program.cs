using System;
using System.Text;

internal class Program
{
    private const int MaxRows = 10;
    private const int MaxColumns = 12;

    static void Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;
        bool running = true;

        while (running)
        {
            Console.WriteLine("======================================");
            Console.WriteLine("   СЕРВІСНИЙ ЦЕНТР РЕМОНТУ АВТОМОБІЛІВ");
            Console.WriteLine("======================================");
            Console.WriteLine("1 — Довідка про програму");
            Console.WriteLine("2 — Таблиця вартості ремонту");
            Console.WriteLine("3 — Суми за видами робіт і місяцями");
            Console.WriteLine("0 — Вихід");
            Console.Write("Ваш вибір: ");

            string choice = Console.ReadLine() ?? "";
            Console.WriteLine();

            switch (choice)
            {
                case "1":
                    Console.WriteLine("Тема: Сервісний центр з ремонту автомобілів");
                    Console.WriteLine("Сутності: Користувач, Замовлення на ремонт, Вид робіт (довідник).");
                    Console.WriteLine("Поля замовлення на ремонт:");
                    Console.WriteLine("int номер замовлення");
                    Console.WriteLine("string марка авто");
                    Console.WriteLine("string держномер");
                    Console.WriteLine("int код виду робіт");
                    Console.WriteLine("DateTime дата прийому");
                    Console.WriteLine("double вартість робіт");
                    Console.WriteLine("double вартість запчастин");
                    Console.WriteLine("string статус");
                    Console.WriteLine("Підсумкова величина: сума по кожному виду робіт за місяць.");
                    break;

                case "2":
                    Console.WriteLine("ТАБЛИЦЯ ОРІЄНТОВНОЇ ВАРТОСТІ РЕМОНТУ");
                    Console.Write("Початок (години): ");
                    if (!double.TryParse(Console.ReadLine(), out double start) || start < 0)
                    {
                        Console.WriteLine("Помилка: початок має бути невід'ємним числом.");
                        break;
                    }

                    Console.Write("Кінець (години): ");
                    if (!double.TryParse(Console.ReadLine(), out double end) || end < start)
                    {
                        Console.WriteLine("Помилка: кінець має бути числом не меншим за початок.");
                        break;
                    }

                    Console.Write("Крок (дробове число більше 0): ");
                    if (!double.TryParse(Console.ReadLine(), out double step) ||
                        double.IsNaN(step) || double.IsInfinity(step) || step <= 0)
                    {
                        Console.WriteLine("Помилка: крок має бути додатним числом.");
                        break;
                    }

                    Console.WriteLine();
                    Console.WriteLine($"{"Години",12} | {"Вартість, грн",18}");
                    Console.WriteLine(new string('-', 34));

                    for (double hours = start; hours <= end + 1e-9; hours += step)
                    {
                        double laborCost = hours * 850.0;
                        double partsCost = 1200.0;
                        double total = laborCost + partsCost;
                        Console.WriteLine($"{hours,12:F2} | {total,18:F2}");
                    }
                    break;

                case "3":
                    Console.WriteLine("СУМИ ЗА ВИДАМИ РОБІТ І МІСЯЦЯМИ");
                    Console.Write($"Кількість видів робіт (1..{MaxRows}): ");
                    if (!int.TryParse(Console.ReadLine(), out int rows) || rows <= 0 || rows > MaxRows)
                    {
                        Console.WriteLine($"Помилка: введіть ціле число від 1 до {MaxRows}. Таблицю не побудовано.");
                        break;
                    }

                    Console.Write($"Кількість місяців (1..{MaxColumns}): ");
                    if (!int.TryParse(Console.ReadLine(), out int columns) ||
                        columns <= 0 || columns > MaxColumns)
                    {
                        Console.WriteLine($"Помилка: введіть ціле число від 1 до {MaxColumns}. Таблицю не побудовано.");
                        break;
                    }

                    // Масиви мають фіксовану довжину; використовуємо лише введену частину.
                    double[,] amounts = new double[MaxRows, MaxColumns];
                    double[] columnTotals = new double[MaxColumns];
                    double grandTotal = 0;

                    for (int row = 0; row < rows; row++)
                    {
                        double rowTotal = 0;

                        for (int column = 0; column < columns; column++)
                        {
                            amounts[row, column] = (row + 1) * 1000 + (column + 1) * 500;
                            rowTotal += amounts[row, column];
                            columnTotals[column] += amounts[row, column];
                        }

                        grandTotal += rowTotal;
                    }

                    Console.WriteLine();
                    Console.Write($"{"Вид робіт",14}");
                    for (int column = 0; column < columns; column++)
                        Console.Write($" | {"Місяць " + (column + 1),12}");
                    Console.WriteLine($" | {"Разом",12}");
                    Console.WriteLine(new string('-', 16 + (columns + 1) * 15));

                    for (int row = 0; row < rows; row++)
                    {
                        double rowTotal = 0;
                        Console.Write($"{"Вид " + (row + 1),14}");

                        for (int column = 0; column < columns; column++)
                        {
                            Console.Write($" | {amounts[row, column],12:F2}");
                            rowTotal += amounts[row, column];
                        }

                        Console.WriteLine($" | {rowTotal,12:F2}");
                    }

                    Console.WriteLine(new string('-', 16 + (columns + 1) * 15));
                    Console.Write($"{"Разом",14}");
                    for (int column = 0; column < columns; column++)
                        Console.Write($" | {columnTotals[column],12:F2}");
                    Console.WriteLine($" | {grandTotal,12:F2}");
                    Console.WriteLine("Примітка: суми умовні, демонстраційні.");
                    break;

                case "0":
                    running = false;
                    break;

                default:
                    Console.WriteLine("Немає такого пункту меню.");
                    break;
            }

            if (running)
                Pause();
        }

        Console.WriteLine("Роботу програми завершено.");
    }

    // Пауза перед поверненням до меню; екран очищується після натискання клавіші.
    static void Pause()
    {
        Console.WriteLine();
        Console.WriteLine("Натисніть будь-яку клавішу, щоб повернутися до меню...");
        Console.ReadKey(true);
        Console.Clear();
    }
}
